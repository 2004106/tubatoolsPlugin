
                           *** Total Uninstall ***
=================================================================================
Total Uninstall is a complete uninstaller which includes five working modes:
  - "Installed programs" module analyzes existing installations and create a log
with installation changes. It can  uninstall applications even without
the help of the built-in uninstall program.
  - "Monitored programs" module helps to monitor any changes made to your 
system during the installation of a new application. It allows you to perform
a complete uninstall without having to rely on the supplied uninstaller program
which can leave files or changes behind.
  - "Windows apps" module uninstall Windows apps.
  - "Cleaner" - scans and clean safe disposable items 
  - "Auto-run manager" - Manage the Windows startup procedure. Control which program,
service or scheduled task automatically start up. 


Features
==============
 - Accurate analyze existing installations and create a log with installation changes.
 - Monitor changes from registry and file system for new installations 
 - Completely and thoroughly uninstall monitored or analyzed programs
 - Force uninstall partial or corrupted programs
 - Batch uninstall programs
 - Backup and restore uninstalled programs
 - Organize in groups installed or monitored programs
 - Find the program to uninstall by keyword or shortcut drag and drop.
 - Summary and detailed information for each installed or monitored program
 - User configurable views of the detected changes
 - Detailed uninstall log
 - Powerful search in detected changes
 - Stand-alone and low resource usage agent for notification of running installation programs
 - Export registry for install or uninstall
 - Export installed or monitored programs list to file
 - Export to file or print detected changes
 - View and apply pending file rename operations without restart
 - Scans and clean safe disposable items

Operating System compatibility
==============================
Total Uninstall is compatible with 64 bit operating systems:
   Windows 11, Windows 10, Windows 8.1, Windows 8, Windows 7
   Windows Server 2025, Windows Server 2022, Window Server 2019, Windows Server 2016   


Contact Information
===================
Check for new releases  :  https://www.martau.com/
Technical Support Email :  support@martau.com

(c) 2001-2025 Gavrila Martau. All Rights Reserved.